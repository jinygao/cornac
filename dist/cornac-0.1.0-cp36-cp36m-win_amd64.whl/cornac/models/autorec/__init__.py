
from .recom_autorec import Autorec


__all__ = ['Autorec']